//
//  TsViewController.h
//  hello333
//
//  Created by Ibokan on 13-6-24.
//  Copyright (c) 2013年 stjy. All rights reserved.
//

#import <UIKit/UIKit.h>
#define COOKBOOK_PURPLE_COLOR	[UIColor colorWithRed:0.20392f green:0.19607f blue:0.61176f alpha:1.0f]

#define CRAYON_NAME(CRAYON)	[[CRAYON componentsSeparatedByString:@"#"] objectAtIndex:0]
#define CRAYON_COLOR(CRAYON) [self getColor:[[CRAYON componentsSeparatedByString:@"#"] lastObject]]

#define DEFAULTKEYS [self.crayonColors.allKeys sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)]
#define FILTEREDKEYS [self.filteredArray sortedArrayUsingSelector:@selector(caseInsensitiveCompare:)]

#define ALPHA	@"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
@interface TsViewController : UITableViewController
{
	NSMutableDictionary *crayonColors;
	NSArray *filteredArray;
	NSMutableArray *sectionArray;
	UISearchBar *searchBar;
	UISearchDisplayController *searchDC;
}
@property (retain) NSMutableDictionary *crayonColors;
@property (retain) NSArray *filteredArray;
@property (retain) NSMutableArray *sectionArray;
@property (retain) UISearchBar *searchBar;
@property (retain) UISearchDisplayController *searchDC;
@end
