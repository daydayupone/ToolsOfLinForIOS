//
//  FirstViewController.m
//  hello333
//
//  Created by Ibokan on 13-6-24.
//  Copyright (c) 2013年 stjy. All rights reserved.
//

#import "FirstViewController.h"
#import "TsViewController.h"
@interface FirstViewController ()

@end

@implementation FirstViewController
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
//完成跳转到指定section
- (IBAction)btnClick:(id)sender {
    TsViewController *ts=[[TsViewController alloc]init];
    [self presentModalViewController:ts animated:YES];
    NSString *t2=[sender titleForState:UIControlStateNormal];
    NSLog(@"%@",t2);
    NSArray *alp=[ALPHA5 componentsSeparatedByString:@","];
    int t=[ALPHA rangeOfString:t2].location;//字母的section位置
    int h1=t*40;//每个section高30
    int h2=0;
    for (int i=0; i<t; i++) {
        h2+=[[ts.sectionArray objectAtIndex:i] count];
    }
    h2*=50;//每个单元格高40
    int h3=h1+h2;
    //460是屏幕高 44是搜索栏的高 测试时注意
    [ts.tableView scrollRectToVisible:CGRectMake(0, h3+460+44, 320, 1) animated:NO];
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
