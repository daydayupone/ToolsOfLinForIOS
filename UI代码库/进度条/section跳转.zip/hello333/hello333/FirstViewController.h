//
//  FirstViewController.h
//  hello333
//
//  Created by Ibokan on 13-6-24.
//  Copyright (c) 2013年 stjy. All rights reserved.
//

#import <UIKit/UIKit.h>
#define ALPHA5	@"A,B,C,D,E,F,G,H,I,J,K,L,M,N,O,P,Q,R,S,T,U,V,W,X,Y,Z"
@interface FirstViewController : UIViewController
@end
