//
//  Student.m
//  UI007_CoreData_Cell
//
//  Copyright (c) 2013年 LJY. All rights reserved.
//

#import "Student.h"


@implementation Student

@dynamic stuid;
@dynamic stuname;
@dynamic stuphone;
@dynamic stuhead;

@end
