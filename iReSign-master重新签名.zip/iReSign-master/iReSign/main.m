//
//  main.m
//  iReSign
//
//  Created by Maciej Swic on 2011-05-16.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
    return NSApplicationMain(argc, (const char **)argv);
}
